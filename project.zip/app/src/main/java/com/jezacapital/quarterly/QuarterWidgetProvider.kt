package com.jezacapital.quarterly

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.SystemClock
import android.widget.RemoteViews
import java.time.Duration
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import java.util.Locale

/**
 * JEZAcapital - 90-minute Quarterly Theory widget (New York time).
 *
 * The trading day starts at 18:00 NY and is split into four 6-hour sessions,
 * each split into four 90-minute quarters:
 *   ASIA 18:00-00:00 | LONDON 00:00-06:00 | NEW YORK AM 06:00-12:00 | NEW YORK PM 12:00-18:00
 */
class QuarterWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val state = currentState()
        ids.forEach { manager.updateAppWidget(it, buildViews(context, state)) }
        scheduleNextBoundary(context, state)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH || intent.action == Intent.ACTION_TIME_CHANGED) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, QuarterWidgetProvider::class.java))
            if (ids.isNotEmpty()) onUpdate(context, manager, ids)
        }
    }

    override fun onDisabled(context: Context) {
        context.getSystemService(AlarmManager::class.java).cancel(refreshIntent(context))
    }

    // ---------------------------------------------------------------- state

    private data class State(
        val session: String,
        val sessionStartMin: Int,   // minute of day (NY) when the session starts
        val quarter: Int,           // 0..3
        val remainingMs: Long
    )

    private fun currentState(): State {
        val now = ZonedDateTime.now(NY)
        val minuteOfDay = now.hour * 60 + now.minute
        val shifted = (minuteOfDay - DAY_START + 1440) % 1440   // 0 = 18:00 NY
        val sessionIdx = shifted / 360
        val intoSession = shifted % 360
        val quarter = intoSession / 90
        val quarterStart = now.truncatedTo(ChronoUnit.MINUTES)
            .minusMinutes((intoSession % 90).toLong())
        val remaining = Duration.between(now, quarterStart.plusMinutes(90)).toMillis()
        return State(
            session = SESSIONS[sessionIdx],
            sessionStartMin = (DAY_START + sessionIdx * 360) % 1440,
            quarter = quarter,
            remainingMs = remaining
        )
    }

    // ---------------------------------------------------------------- views

    private fun buildViews(context: Context, s: State): RemoteViews {
        val v = RemoteViews(context.packageName, R.layout.widget_quarterly)

        v.setTextViewText(R.id.tv_session, s.session)
        v.setTextViewText(R.id.tv_quarter_label, "Q${s.quarter + 1} ends in")

        // Live countdown that ticks by itself (no per-second updates needed)
        v.setChronometerCountDown(R.id.ch_remaining, true)
        v.setChronometer(R.id.ch_remaining, SystemClock.elapsedRealtime() + s.remainingMs, null, true)

        QUARTER_IDS.forEachIndexed { i, id ->
            val start = (s.sessionStartMin + i * 90) % 1440
            v.setTextViewText(id, String.format(Locale.US, "Q%d\n%02d:%02d", i + 1, start / 60, start % 60))
            val active = i == s.quarter
            v.setInt(id, "setBackgroundResource",
                if (active) R.drawable.bg_quarter_active else R.drawable.bg_quarter)
            v.setTextColor(id, if (active) COLOR_ACTIVE_TEXT else COLOR_IDLE_TEXT)
        }

        v.setOnClickPendingIntent(R.id.root, refreshIntent(context))
        return v
    }

    // ---------------------------------------------------------------- alarm

    private fun refreshIntent(context: Context): PendingIntent {
        val intent = Intent(context, QuarterWidgetProvider::class.java).setAction(ACTION_REFRESH)
        return PendingIntent.getBroadcast(
            context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Wake the widget exactly when the next 90-minute quarter starts. */
    private fun scheduleNextBoundary(context: Context, s: State) {
        val am = context.getSystemService(AlarmManager::class.java)
        val trigger = System.currentTimeMillis() + s.remainingMs + 500
        val pi = refreshIntent(context)
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        if (canExact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    companion object {
        private const val ACTION_REFRESH = "com.jezacapital.quarterly.REFRESH"
        private val NY: ZoneId = ZoneId.of("America/New_York")
        private const val DAY_START = 18 * 60
        private val SESSIONS = listOf("ASIA", "LONDON", "NEW YORK AM", "NEW YORK PM")
        private val QUARTER_IDS = listOf(R.id.q1, R.id.q2, R.id.q3, R.id.q4)
        private val COLOR_ACTIVE_TEXT = Color.parseColor("#0B1F14")
        private val COLOR_IDLE_TEXT = Color.parseColor("#A5D6A7")
    }
}
